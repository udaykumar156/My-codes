I've separated the code into two main files: 

#### RedditParser.py
Uses the API and does the sentiment labeling.
Also, stores the headlines in two separate files. Keep in mind that when you run RedditParser.py, it will
download the newest headlines, so results may vary from day to day.

#### Analysis.py
The main file for the analysis shown in the article. And BarChart is simple file that compiles,
the barchart regarding the categories distribution.


Link to post: [Sentiment Analysis on Reddit News Headlines with Python’s Natural Language Toolkit (NLTK)](http://www.learndatasci.com/sentiment-analysis-reddit-headlines-pythons-nltk/)
